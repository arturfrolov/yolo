// import 'bootstrap';
// import forms from '../../components/modal/modal';
// import pageUp from '../../blocks/read-more/pageup';
// import header from '../../blocks/header/header';
//
// header();
// forms('form', '.modal', '.modal-close');
// pageUp();
